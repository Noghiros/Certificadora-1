package com.mycompany.certificadora1;


public class Certificadora1 {

    public static void main(String[] args) {
        System.out.println("Sistema Online");
    }
}
